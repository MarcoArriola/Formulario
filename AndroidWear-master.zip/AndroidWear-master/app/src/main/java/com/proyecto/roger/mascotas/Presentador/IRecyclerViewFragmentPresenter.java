package com.proyecto.roger.mascotas.Presentador;

/**
 * Created by Joan on 28/06/2016.
 */
public interface IRecyclerViewFragmentPresenter {
    public void obtenerMediosRecientes();
    public void mostrarMascotasRV();
}
