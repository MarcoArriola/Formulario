package com.proyecto.roger.mascotas.Mail;

public class Config {

    public static final String EMAIL ="pruebitacurso@gmail.com";
    public static final String PASSWORD ="SuperPrueba";
}
