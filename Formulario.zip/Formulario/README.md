# tarea1_Android

![Alt text](https://github.com/cabr93/tarea1_Android/blob/2/Screenshot1.png )
![Alt text](https://github.com/cabr93/tarea1_Android/blob/2/Screenshot2.png )
![Alt text](https://github.com/cabr93/tarea1_Android/blob/2/Screenshot3.png )
